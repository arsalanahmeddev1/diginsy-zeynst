<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Google tag (gtag.js) -->
  <script async defer src="https://www.googletagmanager.com/gtag/js?id=G-PNM05H2BF7"></script>
  <script>
    setTimeout(function() {
      window.dataLayer = window.dataLayer || [];

      function gtag() {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'G-PNM05H2BF7');
    }, 5000); // Delay in milliseconds
  </script>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $pageTitle; ?></title>
  <meta name="description" content="<?php echo $pageDescription; ?>">
  <link async rel="icon" type="image/png" sizes="16x16" href="./images/fav-icon.webp">
  <style>
    .banner_bg_color {
      background: #f9f9f9;
    }

    .bg_navbar {
      background: #ffffff;
      border-radius: 7px;
      padding: 15px 30px;
      box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
    }

    .bg_navbar {
      padding-top: 12px !important;
      padding-bottom: 12px !important;
    }

    nav ul li {
      font-weight: 600;
      color: #222222;
    }

    .nav_logo {
      max-width: 55px;
    }

    .nav-link {
      color: #222222 !important;
    }

    .nav-link:hover {
      color: #ff5b46 !important;
    }

    .banner_content h1 {
      font-weight: 600;
      font-size: 55px;
      line-height: 85px;
      color: #222222;
      opacity: 1;
      text-shadow: 3px 3px 0 #bebebe, 3px 3px 0 #424242,
        3px 3px 0 rgb(255 255 255 / 30%), 4px 3px rgb(255 255 255 / 30%),
        4px 4px rgb(255 255 255 / 30%) !important;
    }

    .banner_content h1 span {
      color: #ff5b46;
    }

    .circle_banner {
      left: 10%;
      bottom: 10px;
      opacity: 0.5;
      width: 100%;
      max-width: 550px;
      z-index: 1;
    }

    .orange_circle {
      max-width: 160px;
      left: -14%;
      top: 1%;
    }

    .orange_box {
      max-width: 170px;
      bottom: 2%;
      left: -16%;
    }

    .flip_image {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
      height: 522px;
      object-fit: cover;
      width: 100%;
      z-index: 3;
    }

    @media (max-width: 768px) {
      .flip_image {
        height: auto;
        object-fit: cover;
        width: 100%;
        z-index: 3;
      }

      .circle_banner {
        left: 15%;
        bottom: 2%;
        width: 100%;
        max-width: 380px;
      }
    }
  </style>
  <!-- <link async rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
  <link async rel="stylesheet" href="./vendor/vendor.css?v=1">
  <link async rel="stylesheet" href="./css/style.css?v=1">
  <link async rel="stylesheet" href="./css/custom.css?v=1">
  <script>
    // Function to asynchronously load scripts
    function loadScript(src, callback) {
      var script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.onload = callback;
      document.head.appendChild(script);
    }
    // Load Zendesk chat widget script asynchronously after a delay
    setTimeout(function() {
      loadScript('https://static.zdassets.com/ekr/snippet.js?key=18f85f41-59dc-49de-b277-7e774b3231f9');
    }, 5000); // Delay in milliseconds
  </script>

  
</head>

<body>